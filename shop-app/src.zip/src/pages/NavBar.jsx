<nav className="NavBar">
<h2>ShopSphere</h2>
<div className="NavLinks">
    <Link to="/">Home</Link>
    <Link to="/about">About</Link>
    <Link to="/contact">Contact</Link>
    
</div>
</nav>